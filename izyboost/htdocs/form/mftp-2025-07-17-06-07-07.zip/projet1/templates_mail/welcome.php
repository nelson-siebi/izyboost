<?php
echo "bienvenue $nom";
?>