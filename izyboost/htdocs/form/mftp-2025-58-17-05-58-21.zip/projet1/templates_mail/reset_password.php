<?php
echo"modifier le mot de passe $nom et $code";
 ?>